import React from 'react';
import Link from 'next/link';
import Image from 'next/image';


const Header = () => {

  return (
    <div>
   <header className="theme-main-menu sticky-menu theme-menu-four">
          <div className="inner-content container-fluid-lg">
            <div className="d-flex align-items-center">
              <div className="logo order-lg-0">
                <Link href="/about" className="d-block">
                  <Image
                    src="/images/logo/preciousLogoSquare.png"
                    className="navlogo"
                    alt="Logo"
                    width={128}
                    height={128}
                  />
                  <Image
                    src="/images/logo/precious icon.png"
                    className="stickylogo"
                    alt="Logo"
                    width={80}
                    height={80}
                  />

                </Link>
              </div>
              <div className="right-widget d-flex align-items-center ms-auto order-lg-3">
                {/* <div className="call-button d-none d-xl-block me-5">
                  Call us     <Link href="tel:+91-9522280818"> +91-9522280818</Link>
                </div> */}
                <Link href="/contactUs" className="send-msg-btn tran3s d-none d-lg-block ripple-btn">

                  Contact Us

                </Link>
              </div>
              <nav className="navbar navbar-expand-lg order-lg-2">
                <button
                  className="navbar-toggler d-block d-lg-none"
                  type="button"
                  data-bs-toggle="collapse"
                  data-bs-target="#navbarNav"
                  aria-controls="navbarNav"
                  aria-expanded="false"
                  aria-label="Toggle navigation"
                >
                  <span></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarNav">
                  <ul className="navbar-nav">
                    <li className="nav-item active">
                      <Link href="/" className="nav-link">
                        Home
                      </Link>
                    </li>
                    <li className="nav-item">
                      <Link href="/about" className="nav-link">
                        About Us
                      </Link>
                    </li>
                    <li className="nav-item dropdown">
                      <Link href="#" className="nav-link dropdown-toggle">

                        Services

                      </Link>
                      <ul className="dropdown-menu">
                        <li>
                          <Link href="/services/software-development" className="dropdown-item">
                            Software Development Service
                          </Link>
                        </li>
                        <li>
                          <Link href="/services/website-development" className="dropdown-item">
                            Website Development Service
                          </Link>
                        </li>
                        <li>
                          <Link href="/services/full-stack-development" className="dropdown-item">
                            Full-Stack Development Service
                          </Link>
                        </li>
                        <li>
                          <Link href="/services/ui-ux-design" className="dropdown-item">
                            UI/UX Design Service
                          </Link>
                        </li>
                        <li>
                          <Link href="/services/digital-marketing" className="dropdown-item">
                            Digital Marketing Service
                          </Link>
                        </li>
                      </ul>
                    </li>
                    <li className="nav-item">
                      <Link href="/contactUs" className="nav-link">
                        Contact
                      </Link>
                    </li>
                    <li className="nav-item">
                      <Link href="/career" className="nav-link">
                        Career
                      </Link>
                    </li>
                  </ul>
                </div>
              </nav>
            </div>
          </div>
        </header>
    </div>
    
    )}
    export default Header;