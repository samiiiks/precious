import React from 'react';

import Link from 'next/link';
import Head from 'next/head';
import Image from 'next/image';


const Footer = () => {

  return (
    <div>
    <div className="footer-style-four theme-basic-footer">
    <div className="container">
      <div className="inner-wrapper">
        <div className="row">
          <div className="col-lg-4 footer-intro mb-40">
            <div className="footerlogo">
            

            </div>
            <p>
              We are committed to our relentless pursuit of developing efficient
              solutions for small to large companies and individuals to make
              technology work with you, for you!
            </p>
          </div>
          <div className="col-lg-2 col-sm-4 ms-auto mb-30">
            <h5 className="footer-title">Links</h5>
            <ul className="footer-nav-link style-none">
              <li>
                <Link href="/">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about">
                  About us
                </Link>
              </li>
              <li>
                <Link href="/services">
                  Services
                </Link>
              </li>
              <li>
                <Link href="/contact-us">
                  Contact Us
                </Link>
              </li>
              <li>
                <Link href="/faq">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>
          <div className="col-lg-3 col-sm-4 mb-30">
            <h5 className="footer-title">Services</h5>
            <ul className="footer-nav-link style-none">
              <li>
                <Link href="/services/software-development">
                  Software Development Services
                </Link>
              </li>
              <li>
                <Link href="/services/website-development">
                  Website Development Services
                </Link>
              </li>
              <li>
                <Link href="/services/full-stack-development">
                  Full Stack Development Services
                </Link>
              </li>
           
              <li>
                <Link href="/services/digital-marketing">
                  Digital Marketing Services
                </Link>
              </li>
            </ul>
          </div>
          <div className="col-xl-2 col-lg-3 col-sm-4 mb-30">
            <h5 className="footer-title">Social</h5>
            <ul className="d-flex social-icon style-none">
              <li>
                <Link href="https://www.facebook.com/PreciousInfoSystem/" target="_blank">

                  <i className="fab fa-facebook-f" />

                </Link>
              </li>
          
              <li>
                <Link href="https://www.linkedin.com/company/preciousinfosystem/" target="_blank">

                  <i className="fab fa-linkedin-in" />

                </Link>
              </li>
              <li>
                <Link href="https://www.instagram.com/precious.infosystem/" target="_blank">




                  <i className="fab fa-instagram" />

                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="bottom-footer">
          <div className="d-lg-flex justify-content-between align-items-center mt-2">
            <ul className="order-lg-1 pb-15 d-flex justify-content-center footer-nav style-none">
            
            </ul>
            <p className="copyright text-center order-lg-0 pb-15">
              Copyright @2023 | <b>Precious Infosystem Pvt. Ltd.</b>
            </p>
          </div>
        </div>
      </div>
      {/* /.inner-wrapper */}
    </div>
  </div>
  {/* /.footer-style-four */}
   <button className="scroll-top">
    <i className="bi bi-arrow-up-short" />
  </button> 

</div>
    
    )}
    export default Footer;