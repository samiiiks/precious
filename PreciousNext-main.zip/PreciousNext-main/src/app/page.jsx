import React from 'react';
import Script from "next/script";
import Link from 'next/link';
import Head from 'next/head';
import Image from 'next/image';
import '../styles/globals.css';
import Headpage from '../Headpage.jsx';
import Scriptnew from '../Scriptnew.jsx';
// import Preloader from '../Preloader.jsx';
import Header from '../Header.jsx';
import Footer from '../Footer.jsx';
const index = () => {

  return (
    <div>
     
     <Headpage/>
      <div className="main-page-wrapper">
        {/* ===================================================
				Loading Transition
			==================================================== */}

        {/* ===================================================
        Loading Transition
      ==================================================== */}
        
        {/* <Preloader/> */}

        {/* 
			=============================================
				Theme Main Menu
			============================================== 
			*/}
        <Header/>
        {/* /.theme-main-menu */}
        {/* 
			=============================================
				Theme Hero Banner
			============================================== 
			*/}
        <div className="hero-banner-five">
          <div className="container">
            <div className="row">
              <div className="col-xxl-6 col-md-7">
                <h1 className="hero-heading fw-bold wow slideInLeft" data-wow-duration="2s" data-wow-delay="1s">
                  Developing Software For Your Digital <span>Success.</span>
                </h1>
                <p className="text-lg mb-3 pt-40 pe-xl-5 md-pt-30 md-mb-40 wow slideInLeft" data-wow-duration="2s" data-wow-delay="1.2s">
                  We enable businesses to meet today's needs through robust and adaptable digital solutions while unlocking tomorrow's possibilities.
                </p>
                <ul className="style-none button-group d-flex align-items-center wow slideInLeft" data-wow-duration="2s" data-wow-delay="1.4s">
                  <li className="me-4">
                    <Link href="Services.html" className="demo-btn ripple-btn tran3s">

                      Explore Services

                    </Link>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          {/* /.container */}
          <div className="illustration-holder wow slideInRight" data-wow-duration="2s" data-wow-delay="1s">
            <Image src="/images/assets/ils_13.svg" alt="" className="main-illustration ms-auto" width={500} height={400} />
            <Image src="/images/assets/ils_13_1.svg" alt="" className="shapes shape-one" width={400} height={160} />
            <Image src="/images/assets/ils_13_2.svg" alt="" className="shapes shape-two" data-aos="fade-down" width={80} height={80} />
            <Image src="/images/assets/ils_13_2.svg" alt="" className="shapes shape-three" data-aos="fade-down" width={80} height={80} />
          </div>
          <div className="shapes oval-one" />
        </div>
        {/* /.hero-banner-five */}
        {/* 
			=============================================
				Feature Section Seventeen
			============================================== 
			*/}
        
        {/*
			=====================================================
				Counter Section One
			=====================================================
			*/}

        <div className="counter-section-one mt-80 lg-mt-100">
          <div className="container">
            <div className="inner-container bg-color position-relative" data-aos="zoom-in">
              <div className="row justify-content-center">
                <div className="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay={50}>
                  <div className="counter-block-one text-center mb-20">
                    <div className="main-count">
                      <Image src="/images/assets/project.png" alt="" width={80} height={80} />
                    </div>
                    <div className="main-count">
                      <span className="counter">500</span>+
                    </div>
                    <p>projects delivered</p>
                  </div>
                </div>
                <div className="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay={200}>
                  <div className="counter-block-one text-center mb-20">
                    <div className="main-count">
                      <Image src="/images/assets/success.png" alt="" width={80} height={80} />
                    </div>
                    <div className="main-count">
                      <span className="counter">96</span>%
                    </div>
                    <p>enterprise client retention</p>
                  </div>
                </div>
                <div className="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay={350}>
                  <div className="counter-block-one text-center mb-20">
                    <div className="main-count">
                      <Image src="/images/assets/client.png" alt="" width={80} height={80} />
                    </div>
                    <div className="main-count">
                      <span className="counter">300</span>+
                    </div>
                    <p>happy clients</p>
                  </div>
                </div>
                <div className="col-md-3 col-sm-6" data-aos="fade-up" data-aos-delay={500}>
                  <div className="counter-block-one text-center mb-20">
                    <div className="main-count">
                      <Image src="/images/assets/year.png" alt="" width={80} height={80} />
                    </div>
                    <div className="main-count">
                      <span className="counter" id="year">{/* Dynamic content here */}</span>+
                    </div>
                    <p>years of experience</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* /.counter-section-one */}
        {/*
			=====================================================
				Industries and technologies we work with
			=====================================================
			*/}
        <div className="technology-section pt-70">
          <div className="container">
            <div className="block-style-seventeen">
              <h3 className="p-5 text-center" data-aos="zoom-in">
                Technologies We Work With
              </h3>
              <div className="row row-cols-lg-5 row-cols-md-3 row-cols-2 d-flex flex-wrap justify-content-between">
                <div className="text-center p-3 block-style-eighteen" data-aos="fade-up">
                  <Image src="/images/assets/ror.png" alt="technology icon" width={100} height={100} />
                  Ruby On Rails
                </div>
                {/* Rest of the code */}
              </div>
            </div>
            <div className="block-style-seventeen mt-3">
              <h3 className="p-5 text-center" data-aos="fade-up">
                Industries We Serve
              </h3>
              <div className="row">
                <div className="col-md-6 industry-p" data-aos="fade-up">
                  <p>
                    Our industry specific software solutions streamlined business
                    process along with efficient customer’s engagement. We identify
                    opportunities to provide competitive advantages to our clients by
                    leveraging the latest technology. Boost your revenue and drive
                    operational excellence with our customized software industries
                    solutions.
                  </p>
                  <div>
                    <div className="soft-dev" data-aos="fade-up">
                      <Image
                        src="/images/assets/checked.png"
                        className="checked"
                        alt=""
                        width={20}
                        height={20}
                      />
                      Increased company value
                    </div>
                    {/* Rest of the code */}
                  </div>
                </div>
                <div className="col-md-6 md-pt-50" data-aos="fade-left">
                  <Image src="/images/assets/industry.png" alt="industries" width={400} height={400} />
                </div>
              </div>
            </div>
          </div>
        </div>
        {/*
			=====================================================
				Feedback Slider Four
			=====================================================
			*/}
        <div className="feedback-section-five pt-70 lg-pt-70 pb-25 lg-pb-20">
          <div className="container">
            <div className="title-style-three text-center" data-aos="fade-up">
              <div className="sc-title">Testimonials</div>
              <h2 className="main-title">
                Words from <span>Client</span>
              </h2>
            </div>
            <div className="feedback_slider_four pt-10 lg-pt-10" data-aos="fade-up">
                <div className="row">
                  <div className="col-xxl-9 col-xl-10 col-lg-8 m-auto item">
                    <div className="feedback-block-four mb-80 ms-xxl-4 me-xxl-4">
                      <Image src="/images/icon/icon_34.svg" alt="" className="m-auto" height={80} width={80} /> 
                      <div className="row review-box d-flex">
                        <div className="col-sm-3">
                          <Image
                            src="/images/assets/m1.png"
                            alt=""
                            className="mt-sm-0 mt-4"
                            width={100}
                            height={100}
                          />
                        </div>
                        <div className="col-sm-9">
                          <p className="ps-md-3">
                            Precious Infosystem is a delight to work with. There is an
                            incredible team of developers. I believe they would win
                            against the best!
                          </p>
                          <div className="cp-info">
                            <h6>Rich Miller</h6>
                            {/* <span>Front End developer</span> */}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xxl-9 col-xl-10 col-lg-8 m-auto item">
                    <div className="feedback-block-four mb-80 ms-xxl-4 me-xxl-4">
                       <Image src="/../../public/images/icon/icon_34.svg" alt="" className="m-auto" width={80} 
                         height={80} /> 
                      <div className="row review-box d-flex">
                        <div className="col-sm-3">
                          <Image
                            src="/images/assets/m3.jpg"
                            alt=""
                            className="mt-sm-0 mt-4"
                            width={100}
                            height={100}
                          />
                        </div>
                        <div className="col-sm-9">
                          <p className="ps-md-3">
                            It's a pleasure working with Precious Infosystem. They are
                            responsive, communicative, and willing to work on all
                            aspects of the project. They work hard and take pride in
                            it.
                          </p>
                          <div className="cp-info">
                            <h6>Kevin Davis</h6>
                            {/* <span>Front End developer</span> */}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="col-xxl-9 col-xl-10 col-lg-8 m-auto item">
                    <div className="feedback-block-four mb-80 ms-xxl-4 me-xxl-4">
                     <Image src="/../../public/images/icon/icon_34.svg" alt="" className="m-auto" width={80}
                        height={80} /> 
                      <div className="row review-box d-flex">
                        <div className="col-sm-3">
                          <Image
                            src="/images/assets/m3.jpg"
                            alt=""
                            className="mt-sm-0 mt-4"
                            width={100}
                            height={100}
                          />
                        </div>
                        <div className="col-sm-9">
                          <p className="ps-md-3">
                            It's a pleasure working with Precious Infosystem. They are
                            responsive, communicative, and willing to work on all
                            aspects of the project. They work hard and take pride in
                            it.
                          </p>
                          <div className="cp-info">
                            <h6>Kevin Davis</h6>
                            {/* <span>Front End developer</span> */}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
            </div>
            {/* /.feedback_slider_four */}
          </div>
          <Image
            src="/images/assets/m3.jpg"
            alt=""
            className="shapes avatar-one"
            width={45}
            height={45}
            style={{ outlineWidth: 6 }}
          />
          <Image
            src="/images/assets/m1.png"
            alt=""
            className="shapes avatar-two"
            width={85}
            height={85}
            style={{ outlineWidth: 10 }}
          />
          <Image
            src="/images/assets/m2.png"
            alt=""
            className="shapes avatar-three"
            width={85}
            height={85}
            style={{ outlineWidth: 10 }}
          />
          <Image
            src="/images/assets/m3.jpg"
            alt=""
            className="shapes avatar-four"
            width={50}
            height={50}
            style={{ outlineWidth: 5 }}
          />
        </div>
        {/* /.feedback-section-five */}
        {/*
			=====================================================
				Blog Section Three
			=====================================================
			*/}
                {/*
			=====================================================
				Footer
			=====================================================
			*/}
        <div className="subscribe-area theme-basic-footer">
          <div className="container">
            <div className="row align-items-center py-md-5 py-4">
              <div className="col-md-6">
                <div className="title-style-four sm-pb-10">
                  <h3 className="main-title" data-aos="fade-up">
                    Join Our <span>Newsletter</span> and get updated.
                  </h3>
                </div>
              </div>
              <div className="col-md-6">
                <div className="subscribe-form" data-aos="fade-up">
                  <form action="#">
                    <input type="email" placeholder="Enter your email" />
                    <button className="ripple-btn tran3s">Subscribe</button>
                  </form>
                  <p className="mt-md-0 mt-3">
                    We only send interesting and relevant emails.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

       
       <Footer/>
      </div>

<Scriptnew/>
    </div>
  )
}

export default index
